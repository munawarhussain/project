/*
SQLyog Ultimate v11.11 (32 bit)
MySQL - 5.6.11-log : Database - portalvx_discovery
*********************************************************************
*/

/*!40101 SET NAMES utf8 */;

/*!40101 SET SQL_MODE=''*/;

/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
CREATE DATABASE /*!32312 IF NOT EXISTS*/`portalvx_discovery` /*!40100 DEFAULT CHARACTER SET latin1 */;

USE `portalvx_discovery`;

/*Table structure for table `ip_devices` */

DROP TABLE IF EXISTS `ip_devices`;

CREATE TABLE `ip_devices` (
  `ipDeviceID` int(11) NOT NULL AUTO_INCREMENT,
  `discoveryProjectID` int(11) NOT NULL,
  `runDayTime` datetime DEFAULT NULL,
  `hostname` varchar(30) DEFAULT NULL,
  `IPAddressV4` varchar(16) DEFAULT NULL,
  `pingStatusV4` enum('Success','Failed','Not Tested') DEFAULT 'Not Tested',
  `IPAddressV6` varchar(128) DEFAULT NULL,
  `pingStatusV6` enum('Success','Failed','Not Tested') DEFAULT 'Not Tested',
  PRIMARY KEY (`ipDeviceID`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=latin1;

/*Data for the table `ip_devices` */

insert  into `ip_devices`(`ipDeviceID`,`discoveryProjectID`,`runDayTime`,`hostname`,`IPAddressV4`,`pingStatusV4`,`IPAddressV6`,`pingStatusV6`) values (1,1,'2014-07-29 14:14:00','Data Server01','10.10.100.2','Not Tested','','Not Tested'),(2,1,'2014-07-29 14:14:00','Data Server02','10.10.100.3','Not Tested','','Not Tested'),(3,1,'2014-07-29 14:14:00','Data Server03','10.10.100.4','Not Tested','','Not Tested'),(4,2,'2014-07-29 14:34:00','Data Server01','10.10.100.2','Not Tested','','Not Tested'),(5,2,'2014-07-29 14:34:00','Data Server02','10.10.100.3','Not Tested','','Not Tested'),(6,2,'2014-07-29 14:34:00','Data Server03','10.10.100.4','Not Tested','','Not Tested'),(7,3,'2014-07-30 11:45:00','LoadBalancer-001','192.168.120.89','Not Tested','','Not Tested');

/*Table structure for table `project_discovery_status` */

DROP TABLE IF EXISTS `project_discovery_status`;

CREATE TABLE `project_discovery_status` (
  `discoveryProjectID` int(11) NOT NULL AUTO_INCREMENT,
  `discoveryProjectName` varchar(30) NOT NULL,
  `discoveryProjectDescription` varchar(160) DEFAULT 'No text entered by operator',
  `runDay` date DEFAULT NULL,
  `ipProjectDiscoveryStatus` enum('To Be Run','Completed','Failed') DEFAULT 'To Be Run',
  `snmpProjectDiscoveryStatus` enum('To Be Run','Completed','Failed') DEFAULT 'To Be Run',
  `activePortProjectDiscoveryStatus` enum('To Be Run','Completed','Failed') DEFAULT 'To Be Run',
  `other1ProjectDiscoveryStatus` enum('To Be Run','Completed','Failed') DEFAULT 'To Be Run',
  `other2ProjectDiscoveryStatus` enum('To Be Run','Completed','Failed') DEFAULT 'To Be Run',
  `other3ProjectDiscoveryStatus` enum('To Be Run','Completed','Failed') DEFAULT 'To Be Run',
  `other4ProjectDiscoveryStatus` enum('To Be Run','Completed','Failed') DEFAULT 'To Be Run',
  `other5ProjectDiscoveryStatus` enum('To Be Run','Completed','Failed') DEFAULT 'To Be Run',
  `other6ProjectDiscoveryStatus` enum('To Be Run','Completed','Failed') DEFAULT 'To Be Run',
  `other7ProjectDiscoveryStatus` enum('To Be Run','Completed','Failed') DEFAULT 'To Be Run',
  `other8ProjectDiscoveryStatus` enum('To Be Run','Completed','Failed') DEFAULT 'To Be Run',
  `future1` varchar(80) DEFAULT NULL,
  `future2` varchar(80) DEFAULT NULL,
  PRIMARY KEY (`discoveryProjectID`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;

/*Data for the table `project_discovery_status` */

insert  into `project_discovery_status`(`discoveryProjectID`,`discoveryProjectName`,`discoveryProjectDescription`,`runDay`,`ipProjectDiscoveryStatus`,`snmpProjectDiscoveryStatus`,`activePortProjectDiscoveryStatus`,`other1ProjectDiscoveryStatus`,`other2ProjectDiscoveryStatus`,`other3ProjectDiscoveryStatus`,`other4ProjectDiscoveryStatus`,`other5ProjectDiscoveryStatus`,`other6ProjectDiscoveryStatus`,`other7ProjectDiscoveryStatus`,`other8ProjectDiscoveryStatus`,`future1`,`future2`) values (1,'Shell Belgium','Scan of core subnet on DEV network','2014-07-29','Completed','Completed','To Be Run','To Be Run','To Be Run','To Be Run','To Be Run','To Be Run','To Be Run','To Be Run','To Be Run',NULL,NULL),(2,'Shell Belgium','Scan of Management subnet on DEV network','2014-07-29','Completed','To Be Run','To Be Run','To Be Run','To Be Run','To Be Run','To Be Run','To Be Run','To Be Run','To Be Run','To Be Run',NULL,NULL),(3,'GSK Paris','Server farm scan before upgrade','2014-07-30','To Be Run','To Be Run','To Be Run','To Be Run','To Be Run','To Be Run','To Be Run','To Be Run','To Be Run','To Be Run','To Be Run',NULL,NULL),(4,'testing','testing testing testing','2014-08-17','To Be Run','Failed','Completed','Failed','To Be Run','To Be Run','To Be Run','To Be Run','To Be Run','To Be Run','To Be Run',NULL,NULL);

/*Table structure for table `snmp_devices` */

DROP TABLE IF EXISTS `snmp_devices`;

CREATE TABLE `snmp_devices` (
  `snmpDeviceID` int(11) NOT NULL AUTO_INCREMENT,
  `discoveryProjectID` int(11) NOT NULL,
  `ipDeviceID` int(11) NOT NULL,
  `runDayTime` datetime DEFAULT NULL,
  `hostname` varchar(20) DEFAULT NULL,
  `IPAddressV4` varchar(16) DEFAULT NULL,
  `IPAddressV6` varchar(128) DEFAULT NULL,
  `snmpStringV1V2` varchar(32) DEFAULT NULL,
  `snmpDeviceDiscoveryStatus` enum('Not Run','Success','No Response') DEFAULT 'Not Run',
  `snmpDeviceVersionResponse` enum('Unknown','V1','V2','V3') DEFAULT 'Unknown',
  `sysName` varchar(32) DEFAULT NULL,
  `sysDescr` varchar(255) DEFAULT NULL,
  `sysObjectID` varchar(64) DEFAULT NULL,
  `sysContact` varchar(64) DEFAULT NULL,
  `sysLocation` varchar(64) DEFAULT NULL,
  `sysServices` varchar(64) DEFAULT NULL,
  `snmpTypeV3` enum('Not Defined','noAuthNoPriv','authNoPriv','authPriv') DEFAULT 'Not Defined',
  `snmpV3noAuthUser` varchar(32) DEFAULT NULL,
  `snmpV3authUser` varchar(32) DEFAULT NULL,
  `snmpV3privUser` varchar(32) DEFAULT NULL,
  `snmpV3authProtocol` varchar(32) DEFAULT NULL,
  `snmpV3authPassword` varchar(32) DEFAULT NULL,
  `snmpV3privProtocol` varchar(32) DEFAULT NULL,
  `snmpV3privPassword` varchar(32) DEFAULT NULL,
  PRIMARY KEY (`snmpDeviceID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `snmp_devices` */

/*Table structure for table `snmp_interfaces` */

DROP TABLE IF EXISTS `snmp_interfaces`;

CREATE TABLE `snmp_interfaces` (
  `snmpInterfaceID` int(11) NOT NULL AUTO_INCREMENT,
  `discoveryProjectID` int(11) NOT NULL,
  `ipDeviceID` int(11) NOT NULL,
  `snmpDeviceID` int(11) NOT NULL,
  `runDayTime` datetime DEFAULT NULL,
  `ifIndex` int(11) DEFAULT NULL,
  `ifDescr` varchar(255) DEFAULT NULL,
  `ifType` int(11) DEFAULT NULL,
  `ifSpeed` int(11) DEFAULT NULL,
  `ifPhysAddress` varchar(32) DEFAULT NULL,
  `ifAdminStatus` int(11) DEFAULT NULL,
  `ifOperStatus` int(11) DEFAULT NULL,
  PRIMARY KEY (`snmpInterfaceID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `snmp_interfaces` */

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;
