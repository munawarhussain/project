<?php
include("adodb5/adodb.inc.php");
$db = NewADOConnection('mysql');
require_once("connection.php");
require_once("./model/ip_device.php");
$ip_device = new ip_devices();
?>