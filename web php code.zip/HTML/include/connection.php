<?php
class databaseConnection
{
    private $server = "localhost";
    private $username = "root";
    private $password = "";
    private $database = "discovery1";
    public $db;
    public function __construct()
    {
        $this->db = NewADOConnection('mysql');
        $this->db->Connect($this->server,$this->username,$this->password,$this->database);
    }

    public function getRow()
    {
        $row = $this->db->GetRow("select * from ip_devices where ipDeviceID = 1");
        return $row;
    }
}
?>