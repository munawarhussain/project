$(document).ready(function(e)
{
    var options = {
        target:'#output',
        beforeSend:beforeSend,
        uploadProgress:OnProgress,
        success:afterSuccess,
        resetForm:true
    };

    $(".ip_discovery").click(function(){
        $(".discovery").fadeOut();
        $("#project_form").submit(function(){
            $(this).ajaxSubmit(options);
            false;
        });
    });

    function beforeSend()
    {
        //alert("Before Send");
        $("#progress").fadeIn();
    }
    function OnProgress(event,position,total,percentComplete)
    {
        //alert("On Progress");
        $(".progress-bar").attr("aria-valuenow",percentComplete);
        $(".progress-bar").text(percentComplete+"%");
        $(".progress-bar").css("width",percentComplete+"%");
    }
    function afterSuccess(data,status,jqXHR)
    {
        $.post("updates.php",{discoveryID:discoveryID},function(data){
            $("#output").html(data);
            $(".optionbtn").fadeIn();
        });
        $.post("statistic.php",{discoveryID:discoveryID},function(data){
            $(".statistic").html(data);
            $(".optionbtn").fadeIn();
        });
    }

});